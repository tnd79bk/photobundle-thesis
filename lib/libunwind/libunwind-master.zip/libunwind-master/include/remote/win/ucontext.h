// This is an incomplete & imprecice implementation of the *nix file
// by the same name


// Since this is only intended for VC++ compilers
// use #pragma once instead of guard macros
#pragma once

#ifdef _MSC_VER // Only for cross compilation to windows

#include <sys/ucontext.h>

#endif // _MSC_VER
