#ifndef elf64_h
#define elf64_h

#ifndef UNW_ELF_CLASS
# define UNW_ELF_CLASS UNW_ELFCLASS64
#endif
#include "elfxx.h"

#endif /* elf64_h */
