Ceres Solver - A non-linear least squares minimizer
===================================================

Please see [ceres-solver.org](http://ceres-solver.org/) for more
information.

WARNING - Do not make GitHub pull requests!
-------------------------------------------

Ceres development happens on
[Gerrit](https://ceres-solver.googlesource.com/), including both
repository hosting and code reviews. The GitHub Repository is a
continuously updated mirror which is primarily meant for issue
tracking. Please see our [Contributing to Ceres Guide](http://ceres-solver.org/contributing.html) for more details.

The upstream Gerrit repository is

    https://ceres-solver.googlesource.com/ceres-solver
